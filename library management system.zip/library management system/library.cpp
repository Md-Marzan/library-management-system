#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

vector<string> splitString(string str);
void showOptions();
void addBook();
int generateBookId();
void viewBooks();
int adminLogin();
int removeBook();
void editBook();

int main()
{

    adminLogin();


    return 0;
}


int adminLogin()
{
    string username,password;
    cout<<"Enter username: ";
    cin>>username;
    cout<<"Enter password: ";
    cin>>password;

    string line, word;

    fstream file ("admin.csv", ios::in);
    if(file.is_open())
    {
        string data;
        while(getline(file, line))
        {
            data = line;
           break;

        }

        vector<string> parts = splitString(data);

            if(parts[0]==username && parts[1]==password){
                showOptions();
            }else{
                cout<<"Invalid login details"<<endl;
            }



    }
    else
        cout<<"Could not open the file\n";



    return 0;
}

vector<string> splitString(string str)
{
    vector<string>words;
    string w = "";
    for (int i=0;i<str.length();i++)
    {
        char x = str[i];
        if (x == ',')
        {
            words.push_back(w);
             w= "";
        }
        else {
            w = w + x;
        }
    }
    words.push_back(w);
    return words;
}

void showOptions()
{
    while(true)
    {
        int option;
        cout<<"Choose an option"<<endl;
        cout<<"1. View books"<<endl;
        cout<<"2. Add books"<<endl;
        cout<<"3. Remove books"<<endl;
          cout<<"4. Edit books"<<endl;
        cout<<"5. Exit"<<endl;

        cin>>option;

        if(option==1){
            viewBooks();
        }
        else if(option==2){
            addBook();
        }else if(option==3){
            removeBook();
        }
        else if(option==4){
            editBook();
        }
        else if(option==5){
            break;
        }
    }

}

int removeBook()
{
    cout<<"Enter book Id"<<endl;
    string bookId;
    cin>>bookId;
    fstream file ("book.csv", ios::in);
    if(file.is_open())
    {
        string line;
        vector<string>books;
        while(getline(file, line))
        {

            books.push_back(line);

        }
        fstream fout;
             fout.open("book.csv", ios::out|ios::trunc);

        for(int i=0;i<books.size();i++){
            if(books[i].find(bookId) != string::npos){
                    cout<<"REMOVED ------ "<<endl;
                continue;
            }


             fout<<books[i]<<"\n";

        }
    }



}


void editBook()
{
    cout<<"Enter book Id"<<endl;
    string bookId;
    cin>>bookId;
     cout<<"Enter new name"<<endl;
    string bookName;
    cin>>bookName;
    fstream file ("book.csv", ios::in);
    if(file.is_open())
    {
        string line;
        vector<string>books;
        while(getline(file, line))
        {

            books.push_back(line);

        }
        fstream fout;
             fout.open("book.csv", ios::out|ios::trunc);


        for(int i=0;i<books.size();i++){
            if(books[i].find(bookId) != string::npos){
                vector<string>parts = splitString(books[i]);
                fout<<parts[0]<<","<<bookName<<"\n";
            }else{
                fout<<books[i]<<"\n";
            }




        }
    }



}


void viewBooks()
{
    fstream file ("book.csv", ios::in);
    if(file.is_open())
    {
        string line;

        while(getline(file, line))
        {
            cout<<line<<endl;

        }
    }

}

void addBook()
{
    string bookname;
    cout<<"Enter the book name without any comma:"<<endl;
    cin>>bookname;
     fstream fout;
     fout.open("book.csv", ios::out|ios::app);
     int id = generateBookId();
     fout<<id<<","
        <<bookname<<"\n";

    cout<<"Successfully added"<<endl;

}

int generateBookId()
{
     int id = 0 ;
     fstream file ("book.csv", ios::in);
    if(file.is_open())
    {
        string line;

        while(getline(file, line))
        {

            id++;

        }
    }
    return id;

}




